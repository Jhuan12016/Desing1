<html>
    <head>
        <title> Titulo </title>
    </head>
    <body>
        <?php
           for($i=0; $i <= 10; $i++){
        ?>
        <h3>Eu nao acredito</h3></br>
        <?php
           }
        ?>
    </body>
</html>
<html> 
    <head>
        <title>PHP 5 - Guia do Programador</title> </head>
            <body> 
<?php
$data = date("d.m.Y H:i:s",time());
<!-- comentario php -->
echo "<p align='center'>Hoje é :$data</p> ";

 

echo "</p>"
?>
</body> </html>
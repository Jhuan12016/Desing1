<!DOCTYPE html>
<html>
    <head>
       
    </head>
    <body>
        <?php
        function imprime($nome=""){
           
           
            echo"Eu nao acredito" . $nome;
        }
       
        imprime("Jhuan");
        ?>
    </body>
</html>
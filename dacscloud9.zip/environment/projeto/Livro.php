<!DOCTYPE html>
<html>
    <head>
       <meta charset="utf - 8" />
    </head>
    <body>
        <?php
        $nome_livros =_POST["nome"];
        $autor_livro =$_POST["autor"];
        $idioma_livro = $POST["idioma"];
            var_dump($_POST["nome"])
            ?>
    </body>
</html>
<html>
    <head>
        <body>
            <?php
           
            $i = 10;
            echo"O valor é: $i ". " seu tipo " .gettype($i);
            echo "</br>is_string" .is_string($i);
             echo "</br>isset" .isset($i);
             var_dump($i);
   
            ?>
        </body>
    </head>
</html>